namespace UIProbe
{
    /// <summary>
    /// 过渡期桥接：把现有 private 绘制方法以 internal 单行包装暴露给模块适配器，
    /// 使 16 个模块 partial 文件在 Step 1 完全不动。
    /// Step 2 随模块状态外迁逐个删除这些桥接。
    /// </summary>
    public partial class UIProbeWindow
    {
        internal void DrawSidebarButtonPublic(Tab tab, string label) => DrawSidebarButton(tab, label);
    }
}
