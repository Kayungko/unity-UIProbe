# UIProbe 扩展 — Claude 工作约定

> 本文件仅本地使用，已在 `.gitignore` 中，不随扩展上线。

## 通用规则
1. 不要手动创建 `.meta` 文件——此类文件由 Unity 引擎自动生成。
2. 所有回答均使用中文。

## 打包 / 发布 Release
发版时使用本地一键打包工具，无需手写导出/压缩/校验流程：

- **脚本**：`BuildTools/UIProbeReleaseExporter.cs`（已 gitignore，仅本地、不上线、也不会被打进 `.unitypackage`）。
- **触发**：Unity 菜单 `UI Probe > 工具 > 导出 Release 包 (unitypackage + zip + sha256)`，
  或通过 MCP `execute_menu_item` 执行同一菜单路径。
- **产物**：一键在 `ReleasePackages/` 生成 `unity-UIProbe-v{VERSION}` 的 `.unitypackage` + 源码 `.zip` + 两个 `.sha256`。
  - 版本号自动取自 `UIProbeUpdateChecker.VERSION`。
  - `.unitypackage` 仅含 `UIProbe/` 子目录。
  - `.sha256` 格式：小写 hex + 两个空格 + 文件名，无换行。

## 多工作树注意
- 本扩展存在多个工作树副本，务必在正确的工作树内操作，避免改错副本。
- 发版相关产物（`*.unitypackage`、`*.meta`）在 `.gitignore` 中被全局忽略，提交到版本库需 `git add -f`。
