using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace UIProbe
{
    /// <summary>
    /// 索引器配置
    /// </summary>
    [Serializable]
    public class IndexerConfig
    {
        public string rootPath = "";
        public string[] bookmarks = new string[0];
        public string[] searchHistory = new string[0];
    }
    
    /// <summary>
    /// 拾取输入方式
    /// </summary>
    public enum PickerInputMode
    {
        RightClick,      // 右键点击（推荐，默认）
        CtrlLeftClick,   // Ctrl + 左键
        MiddleClick,     // 中键点击
        AltLeftClick     // Alt + 左键
    }
    
    /// <summary>
    /// 拾取器配置
    /// </summary>
    [Serializable]
    public class PickerConfig
    {
        public bool autoMode = false;
        public int inputMode = 0; // PickerInputMode as int (默认 RightClick)
    }
    
    /// <summary>
    /// 重名检测配置
    /// </summary>
    [Serializable]
    public class DuplicateCheckerConfig
    {
        public bool checkUIElements = true;
        public bool checkComponents = true;
        public string[] excludedFolders = new string[0];
        
        // Settings from DuplicateDetectionSettings
        public string mode = "Smart"; // DetectionMode enum as string
        public string detectionScope = "Global"; // DuplicateDetectionMode enum as string
        
        public bool enableWhitelist = true;
        public string[] allowedDuplicateNames = new string[] {
            "Viewport", "Content", "Scrollbar", "Scrollbar Horizontal", 
            "Scrollbar Vertical", "Sliding Area", "Handle"
        };
        
        public bool checkUGUIComponentNames = true;
        public string[] uguiComponentsToCheck = new string[] {
            "Image", "Text", "Button", "Toggle"
        };
        
        public bool enablePrefixFilter = false;
        public string[] requiredPrefixes = new string[] {
            "c_", "m_"
        };
        
        // Blacklist (Forbidden)
        public string[] forbiddenDuplicateNames = new string[0];
    }
    
    /// <summary>
    /// 图片规范化工具配置
    /// </summary>
    [Serializable]
    public class ImageNormalizerConfig
    {
        public string lastSourceFolder = "";
        public bool includeSubfolders = true;
        public int targetWidth = 512;
        public int targetHeight = 512;
        public bool forceSquare = true;
        public string alignment = "Center";  // Center 或 KeepOriginal
        public bool overwrite = true;
        public string namingSuffix = "_normalized";
        /// <summary>缩放模式（对应 ResizeMode 枚举字符串）</summary>
        public string resizeMode = "Expand";
        /// <summary>尺寸计算方式（对应 NormalizerSizeMode 枚举字符串）</summary>
        public string sizeMode = "Custom";
        public float scalePercent   = 100f;
        public int   lockWidth      = 512;
        public int   lockHeight     = 512;
        public bool  noUpscale      = false;
        public int   maxDimension   = 0;    // 0 = 不限
    }
    
    /// <summary>
    /// 记录器配置
    /// </summary>
    [Serializable]
    public class RecorderConfig
    {
        public string storagePath = "";
    }
    
    /// <summary>
    /// 问题检测规则配置
    /// </summary>
    [Serializable]
    public class CheckerRulesConfig
    {
        public bool missingImageSprite = true;
        public bool missingTextFont = true;
        public bool unnecessaryRaycastTarget = true;
        public bool badNaming = true;
        public bool emptyText = true;
        public bool missingCanvasGroup = true;
        public bool duplicateName = true;
    }
    
    /// <summary>
    /// 预制体助手配置 (原适配助手)
    /// </summary>
    [Serializable]
    public class HelperConfig
    {
        // Adaptor Settings
        public int lastLayoutType = 0; // 0: Full, 1: Window, 2: Side
        public float paddingLeft = 0f;
        public float paddingRight = 0f;
        public float paddingTop = 0f;
        public float paddingBottom = 0f;
        public float width = 800f;
        public float height = 600f;
        public int sideAlignment = 0; // 0: Left, 1: Right, 2: Top, 3: Bottom
        public bool isStretch = false; // Side widget stretch mode
        
        // Quick Create Settings
        public bool defaultNoRaycastImage = true;
        public bool defaultNoRaycastText = true;
        public System.Collections.Generic.List<string> tmpFontGuids = new System.Collections.Generic.List<string>();
        public int defaultFontIndex = 0;
    }
    
    /// <summary>
    /// 功能模块可见性配置
    /// </summary>
    [Serializable]
    public class ModulesVisibilityConfig
    {
        public bool showPicker = true;
        public bool showIndexer = true;
        public bool showRecorder = true;
        public bool showBrowser = true;
        public bool showDuplicateChecker = true;
        public bool showAssetReferences = true;
        public bool showNestingOverview = true;
        public bool showImageNormalizer = true;
        public bool showScreenshot = true;
        public bool showRichTextGenerator = true;
        public bool showAdaptor = true;
        public bool showFilterNodeScanner = true;
        public bool showAnimationAutoRepair = true;
        public bool showRedGoldResourceImporter = true;
        public bool showResourceDetector = true;
    }

    /// <summary>
    /// 批量命名工具配置
    /// </summary>
    [Serializable]
    public class BatchRenameConfig
    {
        public string lastSourceFolder = "";
        public string lastTargetFolder = "";
        public bool includeSubfolders = false;
        public bool overwriteInPlace = false;
        public string prefix = "";
        public bool keepOriginalName = true;
        public bool enableSequence = false;
        public int seqStart = 1;
        public int seqStep = 1;
        public int seqDigits = 3;
        public string suffix = "";
        public bool updateMeta = true;
    }

    /// <summary>
    /// 大红大金资源修改导入工具配置
    /// </summary>
    [Serializable]
    public class RedGoldResourceImporterConfig
    {
        public string tablePath = "";
        public string imageSourceFolder = "";
        public List<string> imageSourceFolders = new List<string>();
        public bool includeSubfolders = true;
        public string nameColumn = "名称";
        public string qualityColumn = "品质";
        public string gridLongColumn = "格数：长";
        public string gridWideColumn = "格数：宽";
        public string gridCountColumn = "格数";
        public string iconPathColumn = "图标路径";
        public bool overrideGrid = false;
        public int overrideGridLong = 2;
        public int overrideGridWide = 3;
        public int cellPixelSize = 100;
        public int maxOutputEdge = 512;
        public string redOutputFolder = "";
        public string purpleOutputFolder = "";
        public string goldOutputFolder = "";
        public bool overwriteTable = false;
        public string outputTablePath = "";
        public List<QualityConfigEntry> qualityEntries = new List<QualityConfigEntry>();
    }

    /// <summary>
    /// UIProbe 统一配置
    /// </summary>
    [Serializable]
    public class UIProbeConfig
    {
        public string version = "3.9.3";
        public string lastUpdated = "";

        public IndexerConfig indexer = new IndexerConfig();
        public PickerConfig picker = new PickerConfig();
        public DuplicateCheckerConfig duplicateChecker = new DuplicateCheckerConfig();
        public ImageNormalizerConfig imageNormalizer = new ImageNormalizerConfig();
        public BatchRenameConfig batchRename = new BatchRenameConfig();
        public RedGoldResourceImporterConfig redGoldResourceImporter = new RedGoldResourceImporterConfig();
        public RecorderConfig recorder = new RecorderConfig();
        public CheckerRulesConfig checkerRules = new CheckerRulesConfig();
        public HelperConfig helper = new HelperConfig();
        public ModulesVisibilityConfig modulesVisibility = new ModulesVisibilityConfig();
    }
    
    /// <summary>
    /// UIProbe 配置管理器
    /// </summary>
    public static class UIProbeConfigManager
    {
        private static string ConfigPath => Path.Combine(UIProbeStorage.GetSettingsPath(), "config.json");
        
        /// <summary>
        /// 加载配置
        /// </summary>
        public static UIProbeConfig Load()
        {
            try
            {
                if (File.Exists(ConfigPath))
                {
                    string json = File.ReadAllText(ConfigPath);
                    UIProbeConfig config = JsonUtility.FromJson<UIProbeConfig>(json);
                    Debug.Log($"[UIProbeConfig] 配置已加载: {ConfigPath}");
                    return config;
                }
                else
                {
                    Debug.Log($"[UIProbeConfig] 配置文件不存在，将尝试从EditorPrefs迁移");
                    return null;
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"[UIProbeConfig] 加载配置失败: {e.Message}");
                return null;
            }
        }
        
        /// <summary>
        /// 保存配置
        /// </summary>
        public static void Save(UIProbeConfig config)
        {
            try
            {
                config.lastUpdated = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                string json = JsonUtility.ToJson(config, true);
                
                // 确保目录存在
                string directory = Path.GetDirectoryName(ConfigPath);
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }
                
                File.WriteAllText(ConfigPath, json);
                Debug.Log($"[UIProbeConfig] 配置已保存: {ConfigPath}");
            }
            catch (Exception e)
            {
                Debug.LogError($"[UIProbeConfig] 保存配置失败: {e.Message}");
            }
        }
        
        /// <summary>
        /// 从 EditorPrefs 迁移配置（一次性）
        /// </summary>
        public static UIProbeConfig MigrateFromEditorPrefs()
        {
            Debug.Log("[UIProbeConfig] 开始从EditorPrefs迁移配置...");
            
            UIProbeConfig config = new UIProbeConfig();
            
            try
            {
                // 迁移索引器配置
                config.indexer.rootPath = UnityEditor.EditorPrefs.GetString("UIProbe_IndexRootPath", "");
                
                string bookmarksStr = UnityEditor.EditorPrefs.GetString("UIProbe_Bookmarks", "");
                if (!string.IsNullOrEmpty(bookmarksStr))
                {
                    config.indexer.bookmarks = bookmarksStr.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                }
                
                string historyStr = UnityEditor.EditorPrefs.GetString("UIProbe_History", "");
                if (!string.IsNullOrEmpty(historyStr))
                {
                    config.indexer.searchHistory = historyStr.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                }
                
                // 迁移拾取器配置
                config.picker.autoMode = UnityEditor.EditorPrefs.GetBool("UIProbe_AutoPickerMode", false);
                
                // 迁移重名检测配置
                string excludedFoldersJson = UnityEditor.EditorPrefs.GetString("UIProbe_ExcludedFolders", "");
                if (!string.IsNullOrEmpty(excludedFoldersJson))
                {
                    try
                    {
                        var list = JsonUtility.FromJson<System.Collections.Generic.List<string>>(excludedFoldersJson);
                        if (list != null)
                        {
                            config.duplicateChecker.excludedFolders = list.ToArray();
                        }
                    }
                    catch { }
                }
                
                // 迁移记录器配置
                config.recorder.storagePath = UnityEditor.EditorPrefs.GetString("UIProbe_StoragePath", "");
                
                // 保存迁移后的配置
                Save(config);
                
                Debug.Log("[UIProbeConfig] 迁移完成！配置已保存到文件");
                return config;
            }
            catch (Exception e)
            {
                Debug.LogError($"[UIProbeConfig] 迁移失败: {e.Message}");
                return new UIProbeConfig();  // 返回默认配置
            }
        }
    }
}
